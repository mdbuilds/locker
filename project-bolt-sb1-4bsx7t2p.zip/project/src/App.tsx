import { useEffect, useState } from 'react';
import { RangeSelect } from '@/components/RangeSelect';
import { GameScreen } from '@/components/GameScreen';
import { WinScreen } from '@/components/WinScreen';
import { LoseScreen } from '@/components/LoseScreen';
import { StatsScreen } from '@/components/StatsScreen';
import {
  type GamePhase,
  type GuessEntry,
  type RangePreset,
  generateSecret,
  scoreForAttempts,
} from '@/game/types';
import {
  type GameStats,
  loadStats,
  saveStats,
  recordGame,
  resetStats,
} from '@/game/stats';
import { sound } from '@/game/sound';

type Screen = GamePhase | 'stats';

interface GameConfig {
  mode: RangePreset;
  secret: number;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('setup');
  const [config, setConfig] = useState<GameConfig | null>(null);
  const [attempts, setAttempts] = useState(0);
  const [history, setHistory] = useState<GuessEntry[]>([]);
  const [stats, setStats] = useState<GameStats>(() => loadStats());
  const [isNewBest, setIsNewBest] = useState(false);
  const [loseReason, setLoseReason] = useState<'time' | 'guesses'>('time');

  const [muted, setMuted] = useState(false);
  const [musicEnabled, setMusicEnabled] = useState(true);

  useEffect(() => {
    if (musicEnabled && !muted) {
      sound.setMusicEnabled(true);
    }
  }, [musicEnabled, muted]);

  const handleStart = (mode: RangePreset) => {
    setConfig({ mode, secret: generateSecret(mode.min, mode.max) });
    setAttempts(0);
    setHistory([]);
    setIsNewBest(false);
    setScreen('playing');
  };

  const recordResult = (won: boolean, attemptCount: number) => {
    if (!config) return;
    const rangeSize = config.mode.max - config.mode.min + 1;
    const score = won ? scoreForAttempts(attemptCount, rangeSize) : 0;
    const result = recordGame(stats, {
      won,
      attempts: attemptCount,
      score,
      difficulty: config.mode.id,
    });
    setStats(result.stats);
    saveStats(result.stats);
    if (won) setIsNewBest(result.isNewBestScore);
  };

  const handleGuess = (value: number) => {
    if (!config) return;
    const attempt = attempts + 1;
    setAttempts(attempt);

    let feedback: GuessEntry['feedback'];
    if (value === config.secret) feedback = 'correct';
    else if (value < config.secret) feedback = 'too-low';
    else feedback = 'too-high';

    const entry: GuessEntry = { value, feedback, attempt };
    setHistory((prev) => [...prev, entry]);

    if (feedback === 'correct') {
      recordResult(true, attempt);
      setTimeout(() => setScreen('won'), 600);
    } else if (config.mode.maxGuesses !== null && attempt >= config.mode.maxGuesses) {
      setLoseReason('guesses');
      recordResult(false, attempt);
      setTimeout(() => setScreen('lost'), 400);
    }
  };

  const handleLose = () => {
    setLoseReason('time');
    recordResult(false, attempts);
    setScreen('lost');
  };

  const handlePlayAgain = () => {
    if (!config) return;
    handleStart(config.mode);
  };

  const handleHome = () => {
    setScreen('setup');
    setConfig(null);
    setHistory([]);
    setAttempts(0);
  };

  const handleToggleMute = () => {
    const next = !muted;
    setMuted(next);
    sound.setMuted(next);
  };

  const handleToggleMusic = () => {
    const next = !musicEnabled;
    setMusicEnabled(next);
    sound.setMusicEnabled(next);
  };

  const handleResetStats = () => {
    const fresh = resetStats();
    setStats(fresh);
  };

  if (screen === 'stats') {
    return <StatsScreen stats={stats} onBack={() => setScreen('setup')} onReset={handleResetStats} />;
  }

  if (screen === 'setup') {
    return (
      <RangeSelect
        onStart={handleStart}
        onShowStats={() => setScreen('stats')}
        bestScore={stats.bestScore}
        muted={muted}
        musicEnabled={musicEnabled}
        onToggleMute={handleToggleMute}
        onToggleMusic={handleToggleMusic}
      />
    );
  }

  if (screen === 'playing' && config) {
    return (
      <GameScreen
        mode={config.mode}
        secret={config.secret}
        attempts={attempts}
        history={history}
        onGuess={handleGuess}
        onQuit={handleHome}
        onLose={handleLose}
      />
    );
  }

  if (screen === 'won' && config) {
    return (
      <WinScreen
        secret={config.secret}
        attempts={attempts}
        rangeSize={config.mode.max - config.mode.min + 1}
        onPlayAgain={handlePlayAgain}
        onHome={handleHome}
        onShowStats={() => setScreen('stats')}
        isNewBest={isNewBest}
      />
    );
  }

  if (screen === 'lost' && config) {
    return (
      <LoseScreen
        secret={config.secret}
        attempts={attempts}
        reason={loseReason}
        onPlayAgain={handlePlayAgain}
        onHome={handleHome}
        onShowStats={() => setScreen('stats')}
      />
    );
  }

  return null;
}
