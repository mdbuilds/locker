import { useEffect, useState } from 'react';

export type MascotMood =
  | 'idle'
  | 'thinking'
  | 'too-low'
  | 'too-high'
  | 'correct'
  | 'close';

interface MascotProps {
  mood: MascotMood;
  size?: number;
}

const MOOD_LABELS: Record<MascotMood, string> = {
  idle: 'READY',
  thinking: 'HMMM',
  'too-low': 'HIGHER',
  'too-high': 'LOWER',
  correct: 'GOT IT!',
  close: 'CLOSE!',
};

const MOOD_COLORS: Record<MascotMood, string> = {
  idle: '#FFD93D',
  thinking: '#6BC5F2',
  'too-low': '#4ECDC4',
  'too-high': '#FF8FAB',
  correct: '#FFD93D',
  close: '#FF9F43',
};

export function Mascot({ mood, size = 120 }: MascotProps) {
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 120);
    }, 3000 + Math.random() * 2000);
    return () => clearInterval(interval);
  }, []);

  const eyeShape =
    mood === 'correct'
      ? 'happy'
      : mood === 'too-high'
        ? 'look-up'
        : mood === 'too-low'
          ? 'look-down'
          : mood === 'close'
            ? 'wide'
            : mood === 'thinking'
              ? 'squint'
              : 'normal';

  const mouthShape =
    mood === 'correct'
      ? 'big-smile'
      : mood === 'too-high' || mood === 'too-low'
        ? 'frown'
        : mood === 'close'
          ? 'o-shape'
          : mood === 'thinking'
            ? 'small'
            : 'smile';

  const accentColor = MOOD_COLORS[mood];

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative" style={{ width: size, height: size }} key={mood}>
        {/* Pulse ring when correct */}
        {mood === 'correct' && (
          <div
            className="absolute inset-[-12px] rounded-2xl animate-pulse-ring"
            style={{ backgroundColor: accentColor + '40' }}
          />
        )}

        {/* Face — Memphis style: rounded square with thick border and hard shadow */}
        <div
          className={`relative h-full w-full rounded-[28px] border-[4px] border-ink-900 transition-transform duration-300 ${
            mood === 'correct'
              ? 'animate-bounce-soft'
              : mood === 'too-high' || mood === 'too-low'
                ? 'animate-shake'
                : mood === 'idle'
                  ? 'animate-bounce-soft'
                  : ''
          }`}
          style={{
            backgroundColor: accentColor,
            boxShadow: '5px 5px 0px 0px #0a0a0a',
          }}
        >
          {/* Decorative dots in corner */}
          <div className="absolute right-[12%] top-[10%] flex gap-1">
            <div className="h-2 w-2 rounded-full bg-ink-900" />
            <div className="h-2 w-2 rounded-full bg-ink-900" />
          </div>

          {/* Eyes */}
          <div className="absolute top-[28%] flex w-full justify-between px-[22%]">
            <Eye shape={eyeShape} blink={blink} />
            <Eye shape={eyeShape} blink={blink} />
          </div>

          {/* Mouth */}
          <div className="absolute bottom-[20%] left-1/2 -translate-x-1/2">
            <Mouth shape={mouthShape} />
          </div>

          {/* Cheeks when correct */}
          {mood === 'correct' && (
            <>
              <div className="absolute bottom-[26%] left-[12%] h-3 w-4 rounded-full border-2 border-ink-900 bg-memphis-coral" />
              <div className="absolute bottom-[26%] right-[12%] h-3 w-4 rounded-full border-2 border-ink-900 bg-memphis-coral" />
            </>
          )}
        </div>
      </div>

      {/* Speech label — Memphis style badge */}
      <div
        key={`label-${mood}`}
        className="animate-pop-in rounded-lg border-[3px] border-ink-900 bg-ink-900 px-4 py-1.5 font-display text-sm font-black uppercase tracking-wider text-memphis-cream"
        style={{ boxShadow: '3px 3px 0px 0px ' + accentColor }}
      >
        {MOOD_LABELS[mood]}
      </div>
    </div>
  );
}

function Eye({ shape, blink }: { shape: string; blink: boolean }) {
  if (shape === 'happy') {
    return (
      <div className="h-5 w-7 rounded-t-full border-t-[4px] border-ink-900" />
    );
  }

  if (shape === 'squint') {
    return (
      <div className="h-1.5 w-7 rounded-full bg-ink-900" />
    );
  }

  if (shape === 'wide') {
    return (
      <div
        className={`relative h-6 w-6 rounded-full border-[3px] border-ink-900 bg-white transition-all duration-150 ${
          blink ? 'h-[2px]' : ''
        }`}
      >
        {!blink && (
          <div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-ink-900" />
        )}
      </div>
    );
  }

  const pupilOffset =
    shape === 'look-up'
      ? '-translate-y-[3px]'
      : shape === 'look-down'
        ? 'translate-y-[3px]'
        : '';

  return (
    <div
      className={`relative h-6 w-6 rounded-full border-[3px] border-ink-900 bg-white transition-all duration-150 ${
        blink ? 'h-[2px]' : ''
      }`}
    >
      {!blink && (
        <div
          className={`absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-ink-900 transition-transform duration-200 ${pupilOffset}`}
        />
      )}
    </div>
  );
}

function Mouth({ shape }: { shape: string }) {
  if (shape === 'big-smile') {
    return (
      <div className="h-7 w-12 rounded-b-full border-b-[5px] border-l-[5px] border-r-[5px] border-ink-900" />
    );
  }
  if (shape === 'smile') {
    return (
      <div className="h-3 w-9 rounded-b-full border-b-[4px] border-ink-900" />
    );
  }
  if (shape === 'frown') {
    return (
      <div className="h-3 w-9 rounded-t-full border-t-[4px] border-ink-900" />
    );
  }
  if (shape === 'o-shape') {
    return (
      <div className="h-5 w-5 rounded-full border-[4px] border-ink-900" />
    );
  }
  // small
  return <div className="h-2 w-7 rounded-full bg-ink-900" />;
}
