import { Mascot } from '@/components/Mascot';
import { Confetti } from '@/components/Confetti';
import { MemphisShapes } from '@/components/MemphisShapes';
import {
  RotateCcw,
  Home,
  Star,
  Hash,
  Trophy,
  BarChart3,
} from 'lucide-react';
import { attemptsToStars, scoreForAttempts } from '@/game/types';
import { sound } from '@/game/sound';
import { useEffect } from 'react';

interface WinScreenProps {
  secret: number;
  attempts: number;
  rangeSize: number;
  onPlayAgain: () => void;
  onHome: () => void;
  onShowStats: () => void;
  isNewBest: boolean;
}

export function WinScreen({
  secret,
  attempts,
  rangeSize,
  onPlayAgain,
  onHome,
  onShowStats,
  isNewBest,
}: WinScreenProps) {
  const score = scoreForAttempts(attempts, rangeSize);
  const stars = attemptsToStars(attempts, rangeSize);

  useEffect(() => {
    const t = setTimeout(() => sound.play('win'), 300);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden px-5 py-8">
      <MemphisShapes count={10} />
      <Confetti count={100} />

      <div className="relative z-10 w-full max-w-sm text-center">
        {/* Mascot */}
        <div className="mb-6 flex justify-center animate-pop-in">
          <Mascot mood="correct" size={110} />
        </div>

        {/* Secret number — hero card */}
        <div
          className="mb-6 animate-pop-in rounded-3xl border-[4px] border-ink-900 bg-ink-900 p-8 shadow-memphis-lg"
          style={{ animationDelay: '150ms' }}
        >
          <div className="mb-2 flex items-center justify-center gap-1.5 font-display text-xs font-black uppercase tracking-widest text-memphis-yellow">
            <Trophy className="h-3.5 w-3.5" />
            Solved
          </div>
          <div className="font-mono text-5xl font-bold text-memphis-cream sm:text-6xl">
            {secret.toLocaleString()}
          </div>
        </div>

        {/* Stars */}
        <div
          className="mb-6 flex justify-center gap-3 animate-slide-up"
          style={{ animationDelay: '300ms' }}
        >
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="transition-all duration-500"
              style={{
                transitionDelay: `${i * 150}ms`,
                transform: i < stars ? 'scale(1) rotate(0)' : 'scale(0.8) rotate(-15deg)',
              }}
            >
              <div
                className={`flex h-12 w-12 items-center justify-center rounded-xl border-[3px] border-ink-900 ${
                  i < stars ? 'bg-memphis-yellow shadow-memphis-sm' : 'bg-ink-100'
                }`}
              >
                <Star
                  className={`h-6 w-6 ${i < stars ? 'fill-ink-900 text-ink-900' : 'text-ink-300'}`}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Stats — compact icon cards */}
        <div
          className="mb-6 grid grid-cols-2 gap-3 animate-slide-up"
          style={{ animationDelay: '400ms' }}
        >
          <div className="rounded-2xl border-[3px] border-ink-900 bg-white p-4 shadow-memphis-sm">
            <div className="mb-1 flex items-center justify-center gap-1.5">
              <Hash className="h-4 w-4 text-ink-400" />
              <span className="font-display text-[10px] font-black uppercase tracking-widest text-ink-400">
                Guesses
              </span>
            </div>
            <div className="font-display text-2xl font-black">{attempts}</div>
          </div>
          <div className="rounded-2xl border-[3px] border-ink-900 bg-memphis-teal p-4 shadow-memphis-sm">
            <div className="mb-1 flex items-center justify-center gap-1.5">
              <Trophy className="h-4 w-4 text-ink-700" />
              <span className="font-display text-[10px] font-black uppercase tracking-widest text-ink-700">
                Score
              </span>
            </div>
            <div className="font-display text-2xl font-black">{score}</div>
            {isNewBest && (
              <div className="mt-0.5 font-display text-[10px] font-black uppercase tracking-wide text-memphis-coral">
                New best!
              </div>
            )}
          </div>
        </div>

        {/* Buttons */}
        <div
          className="flex flex-col gap-3 animate-slide-up"
          style={{ animationDelay: '500ms' }}
        >
          <button
            onClick={onPlayAgain}
            className="group flex w-full items-center justify-center gap-2 rounded-2xl border-[3px] border-ink-900 bg-memphis-coral px-6 py-4 font-display text-base font-black uppercase tracking-wide text-ink-900 shadow-memphis-lg transition-all hover:-translate-y-0.5 active:translate-x-[4px] active:translate-y-[4px] active:shadow-none"
          >
            <RotateCcw className="h-5 w-5 transition-transform duration-300 group-hover:-rotate-180" />
            Play Again
          </button>
          <div className="flex gap-3">
            <button
              onClick={onHome}
              className="flex flex-1 items-center justify-center gap-2 rounded-2xl border-[3px] border-ink-900 bg-white px-4 py-3 font-display text-sm font-black uppercase shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
            >
              <Home className="h-4 w-4" />
              Home
            </button>
            <button
              onClick={onShowStats}
              className="flex flex-1 items-center justify-center gap-2 rounded-2xl border-[3px] border-ink-900 bg-memphis-blue px-4 py-3 font-display text-sm font-black uppercase shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
            >
              <BarChart3 className="h-4 w-4" />
              Stats
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
