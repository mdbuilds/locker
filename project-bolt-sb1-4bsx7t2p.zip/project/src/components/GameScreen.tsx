import { useEffect, useRef, useState } from 'react';
import type { GuessEntry, GuessFeedback, RangePreset } from '@/game/types';
import { Mascot, type MascotMood } from '@/components/Mascot';
import { MemphisShapes } from '@/components/MemphisShapes';
import { RangePoll } from '@/components/RangePoll';
import {
  ArrowDown,
  ArrowUp,
  CornerUpLeft,
  Target,
  Lightbulb,
  Hash,
  Timer,
  Flame,
} from 'lucide-react';
import { sound } from '@/game/sound';

interface GameScreenProps {
  mode: RangePreset;
  secret: number;
  attempts: number;
  history: GuessEntry[];
  onGuess: (value: number) => void;
  onQuit: () => void;
  onLose: () => void;
}

function feedbackToMood(
  fb: GuessFeedback | null,
  lastGuess: number | null,
  secret: number,
): MascotMood {
  if (fb === 'correct') return 'correct';
  if (fb === null) return 'thinking';
  const distance = Math.abs((lastGuess ?? 0) - secret);
  const range = Math.max(1, secret);
  if (distance <= Math.max(2, Math.floor(range * 0.05))) return 'close';
  if (fb === 'too-low') return 'too-low';
  return 'too-high';
}

export function GameScreen({
  mode,
  secret,
  attempts,
  history,
  onGuess,
  onQuit,
  onLose,
}: GameScreenProps) {
  const min = mode.min;
  const max = mode.max;
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const [hintShown, setHintShown] = useState(false);
  const [timeLeft, setTimeLeft] = useState(mode.timerSeconds ?? 0);
  const inputRef = useRef<HTMLInputElement>(null);

  const hasTimer = mode.timerSeconds !== null;
  const hasGuessLimit = mode.maxGuesses !== null;
  const guessesLeft = hasGuessLimit ? (mode.maxGuesses as number) - attempts : Infinity;

  // Countdown timer
  useEffect(() => {
    if (!hasTimer) return;
    if (timeLeft <= 0) return;
    const interval = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(interval);
          sound.play('incorrect');
          onLose();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [hasTimer, timeLeft, onLose]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const lastGuess = history.length > 0 ? history[history.length - 1] : null;
  const mood = feedbackToMood(
    lastGuess?.feedback ?? null,
    lastGuess?.value ?? null,
    secret,
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (guessesLeft <= 0) return;
    const value = parseInt(input, 10);
    if (isNaN(value)) {
      setError('Enter a number');
      return;
    }
    if (value < min || value > max) {
      setError(`${min}–${max.toLocaleString()}`);
      return;
    }
    setError('');
    setInput('');

    const isCorrect = value === secret;
    if (isCorrect) {
      sound.play('correct');
    } else {
      sound.play('incorrect');
    }
    onGuess(value);
  };

  const handleHint = () => {
    sound.play('hint');
    setHintShown(true);
  };

  const lastFeedback = lastGuess?.feedback;
  const showFeedback = lastFeedback && lastFeedback !== 'correct';

  const hintAvailable = history.length >= 3 && !hintShown;
  const timerColor = timeLeft <= 10 ? 'bg-memphis-coral' : 'bg-memphis-yellow';
  const timerText = timeLeft <= 10 ? 'text-memphis-coral' : 'text-ink-900';

  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden px-5 py-6">
      <MemphisShapes count={6} />

      <div className="relative z-10 mx-auto flex w-full max-w-xl flex-1 flex-col">
        {/* Top bar */}
        <div className="mb-4 flex items-center justify-between gap-2">
          <button
            onClick={onQuit}
            className="flex items-center gap-1.5 rounded-lg border-[3px] border-ink-900 bg-white px-3 py-1.5 font-display text-sm font-black uppercase text-ink-900 shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
          >
            <CornerUpLeft className="h-4 w-4" />
            Quit
          </button>
          <div className="flex items-center gap-2">
            {hasTimer && (
              <div className={`flex items-center gap-1.5 rounded-lg border-[3px] border-ink-900 px-3 py-1.5 font-mono text-sm font-bold shadow-memphis-sm ${timerColor} ${timerText}`}>
                <Timer className="h-4 w-4" />
                <span>{timeLeft}s</span>
              </div>
            )}
            {hasGuessLimit && (
              <div className={`flex items-center gap-1.5 rounded-lg border-[3px] border-ink-900 px-3 py-1.5 font-mono text-sm font-bold shadow-memphis-sm ${guessesLeft <= 2 ? 'bg-memphis-coral text-white' : 'bg-white'}`}>
                <Flame className="h-4 w-4" />
                <span>{guessesLeft}</span>
              </div>
            )}
            <div className="flex items-center gap-2 rounded-lg border-[3px] border-ink-900 bg-ink-900 px-3 py-1.5 font-mono text-sm font-bold text-memphis-yellow shadow-memphis-sm">
              <Target className="h-4 w-4" />
              <span>{min}–{max.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Mascot */}
        <div className="mb-4 flex flex-col items-center">
          <Mascot mood={mood} size={80} />
        </div>

        {/* Range poll */}
        <div className="mb-4">
          <RangePoll history={history} min={min} max={max} secret={secret} />
        </div>

        {/* Feedback banner */}
        <div className="mb-4 min-h-[48px]">
          {showFeedback && lastGuess && (
            <div
              key={lastGuess.attempt}
              className={`animate-pop-in flex items-center justify-center gap-3 rounded-2xl border-[3px] p-3 shadow-memphis ${
                lastFeedback === 'too-low'
                  ? 'border-ink-900 bg-memphis-teal'
                  : 'border-ink-900 bg-memphis-pink'
              }`}
            >
              {lastFeedback === 'too-low' ? (
                <><ArrowUp className="h-5 w-5" /><span className="font-display text-base font-black uppercase">Higher</span></>
              ) : (
                <><ArrowDown className="h-5 w-5" /><span className="font-display text-base font-black uppercase">Lower</span></>
              )}
            </div>
          )}
        </div>

        {/* Input + Guess button */}
        <form onSubmit={handleSubmit} className="mb-3">
          <div className="flex gap-3">
            <input
              ref={inputRef}
              type="number"
              inputMode="numeric"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`${min}–${max.toLocaleString()}`}
              disabled={guessesLeft <= 0}
              className="flex-1 rounded-2xl border-[3px] border-ink-900 bg-white px-5 py-3.5 font-mono text-2xl font-bold outline-none transition-all focus:shadow-memphis-sm disabled:opacity-40"
            />
            <button
              type="submit"
              disabled={guessesLeft <= 0}
              className="rounded-2xl border-[3px] border-ink-900 bg-ink-900 px-8 font-display text-lg font-black uppercase text-memphis-cream shadow-memphis transition-all hover:-translate-y-0.5 active:translate-x-[2px] active:translate-y-[2px] active:shadow-none disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none"
            >
              Guess
            </button>
          </div>
          {error && (
            <p className="mt-2 animate-slide-up font-display text-sm font-bold uppercase text-memphis-coral">{error}</p>
          )}
        </form>

        {/* Hint row */}
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 rounded-lg border-[3px] border-ink-900 bg-memphis-yellow px-3 py-1 font-mono text-sm font-bold shadow-memphis-sm">
              <Hash className="h-3.5 w-3.5" />
              <span>{attempts}</span>
            </div>
            {hintAvailable && (
              <button
                onClick={handleHint}
                className="flex items-center gap-1.5 rounded-lg border-[3px] border-ink-900 bg-memphis-lime px-3 py-1 font-display text-sm font-black uppercase shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
              >
                <Lightbulb className="h-3.5 w-3.5" />
                Hint
              </button>
            )}
          </div>
        </div>

        {/* History */}
        <div className="flex-1 overflow-y-auto no-scrollbar">
          {history.length === 0 ? (
            <p className="py-6 text-center font-display text-sm font-bold uppercase text-ink-300">Make your first guess</p>
          ) : (
            <div className="flex flex-col-reverse gap-2">
              {history.map((entry) => {
                const isLow = entry.feedback === 'too-low';
                const isHigh = entry.feedback === 'too-high';
                const isCorrect = entry.feedback === 'correct';
                return (
                  <div
                    key={entry.attempt}
                    className={`animate-slide-in-right flex items-center justify-between rounded-xl border-[3px] px-4 py-2.5 shadow-memphis-sm ${
                      isLow ? 'border-ink-900 bg-white' : isHigh ? 'border-ink-900 bg-memphis-cream' : 'border-ink-900 bg-ink-900 text-memphis-yellow'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs text-ink-400">{entry.attempt}</span>
                      <span className="font-display text-lg font-black">{entry.value.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center">
                      {isLow && <ArrowUp className="h-4 w-4 text-ink-700" />}
                      {isHigh && <ArrowDown className="h-4 w-4 text-ink-700" />}
                      {isCorrect && <span className="font-display text-xs font-black uppercase">Hit</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
