import { useMemo } from 'react';

type ShapeType = 'circle' | 'triangle' | 'square' | 'zigzag' | 'squiggle' | 'dots' | 'half-circle' | 'cross';

interface ShapeDef {
  type: ShapeType;
  color: string;
  top: string;
  left: string;
  size: number;
  rotation: number;
  animation: string;
  animationDelay: string;
}

const MEMPHIS_COLORS = [
  '#FF6B6B',
  '#FFD93D',
  '#4ECDC4',
  '#FF8FAB',
  '#6BC5F2',
  '#C5E063',
  '#FF9F43',
];

function randomShape(i: number): ShapeDef {
  const types: ShapeType[] = ['circle', 'triangle', 'square', 'zigzag', 'squiggle', 'dots', 'half-circle', 'cross'];
  return {
    type: types[i % types.length],
    color: MEMPHIS_COLORS[i % MEMPHIS_COLORS.length],
    top: `${5 + Math.random() * 85}%`,
    left: `${Math.random() * 90}%`,
    size: 24 + Math.random() * 40,
    rotation: Math.random() * 360,
    animation: i % 2 === 0 ? 'animate-float' : 'animate-float-delayed',
    animationDelay: `${Math.random() * 2}s`,
  };
}

export function MemphisShapes({ count = 10 }: { count?: number }) {
  const shapes = useMemo(
    () => Array.from({ length: count }, (_, i) => randomShape(i)),
    [count],
  );

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {shapes.map((shape, i) => (
        <div
          key={i}
          className={`absolute ${shape.animation}`}
          style={{
            top: shape.top,
            left: shape.left,
            animationDelay: shape.animationDelay,
          }}
        >
          <Shape shape={shape} />
        </div>
      ))}
    </div>
  );
}

function Shape({ shape }: { shape: ShapeDef }) {
  const { type, color, size, rotation } = shape;
  const common = {
    width: size,
    height: size,
    transform: `rotate(${rotation}deg)`,
  };

  if (type === 'circle') {
    return (
      <div
        style={{
          ...common,
          borderRadius: '50%',
          backgroundColor: color,
          border: '3px solid #0a0a0a',
        }}
      />
    );
  }

  if (type === 'triangle') {
    return (
      <svg width={size} height={size} viewBox="0 0 100 100" style={{ transform: `rotate(${rotation}deg)` }}>
        <polygon
          points="50,8 92,88 8,88"
          fill={color}
          stroke="#0a0a0a"
          strokeWidth="6"
          strokeLinejoin="round"
        />
      </svg>
    );
  }

  if (type === 'square') {
    return (
      <div
        style={{
          ...common,
          backgroundColor: color,
          border: '3px solid #0a0a0a',
          borderRadius: '4px',
        }}
      />
    );
  }

  if (type === 'half-circle') {
    return (
      <svg width={size} height={size / 2} viewBox="0 0 100 50" style={{ transform: `rotate(${rotation}deg)` }}>
        <path
          d="M 5 50 A 45 45 0 0 1 95 50 Z"
          fill={color}
          stroke="#0a0a0a"
          strokeWidth="6"
          strokeLinejoin="round"
        />
      </svg>
    );
  }

  if (type === 'cross') {
    return (
      <svg width={size} height={size} viewBox="0 0 100 100" style={{ transform: `rotate(${rotation}deg)` }}>
        <rect x="40" y="5" width="20" height="90" fill={color} stroke="#0a0a0a" strokeWidth="6" rx="4" />
        <rect x="5" y="40" width="90" height="20" fill={color} stroke="#0a0a0a" strokeWidth="6" rx="4" />
      </svg>
    );
  }

  if (type === 'zigzag') {
    return (
      <svg width={size} height={size * 0.6} viewBox="0 0 100 60" style={{ transform: `rotate(${rotation}deg)` }}>
        <polyline
          points="5,50 20,10 35,50 50,10 65,50 80,10 95,50"
          fill="none"
          stroke={color}
          strokeWidth="7"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  }

  if (type === 'squiggle') {
    return (
      <svg width={size} height={size * 0.5} viewBox="0 0 100 50" style={{ transform: `rotate(${rotation}deg)` }}>
        <path
          d="M 5 25 Q 17.5 5, 30 25 T 55 25 T 80 25 T 95 25"
          fill="none"
          stroke={color}
          strokeWidth="6"
          strokeLinecap="round"
        />
      </svg>
    );
  }

  // dots pattern
  return (
    <div
      style={{
        width: size,
        height: size,
        color,
      }}
      className="bg-dots-color"
    />
  );
}
