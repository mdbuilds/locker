import { useState } from 'react';
import { RANGE_PRESETS, type Difficulty, type RangePreset } from '@/game/types';
import { Mascot } from '@/components/Mascot';
import { MemphisShapes } from '@/components/MemphisShapes';
import { ArrowRight, BarChart3, Volume2, VolumeX, Music, Music2, Timer, Hash, SlidersHorizontal } from 'lucide-react';
import { sound } from '@/game/sound';

interface RangeSelectProps {
  onStart: (mode: RangePreset) => void;
  onShowStats: () => void;
  bestScore: number | null;
  muted: boolean;
  musicEnabled: boolean;
  onToggleMute: () => void;
  onToggleMusic: () => void;
}

const MODE_COLORS: Record<Difficulty, string> = {
  standard: '#C5E063',
  strict: '#6BC5F2',
  speedrun: '#FFD93D',
  hardcore: '#FF6B6B',
  relaxed: '#4ECDC4',
  custom: '#FF9F43',
};

const QUICK_RANGES = [10, 100, 500, 1000, 10000];

export function RangeSelect({
  onStart,
  onShowStats,
  bestScore,
  muted,
  musicEnabled,
  onToggleMute,
  onToggleMusic,
}: RangeSelectProps) {
  const [selected, setSelected] = useState<Difficulty>('standard');
  const [min, setMin] = useState('1');
  const [max, setMax] = useState('100');
  const [customGuessLimit, setCustomGuessLimit] = useState('8');
  const [customTimer, setCustomTimer] = useState('');
  const [customGuessEnabled, setCustomGuessEnabled] = useState(true);
  const [customTimerEnabled, setCustomTimerEnabled] = useState(false);
  const [error, setError] = useState('');

  const activePreset = RANGE_PRESETS.find((mode) => mode.id === selected) ?? RANGE_PRESETS[0];

  const selectMode = (mode: RangePreset) => {
    sound.resume();
    sound.play('click');
    setSelected(mode.id);
    setError('');
  };

  const setQuickRange = (value: number) => {
    sound.resume();
    sound.play('click');
    setMin('1');
    setMax(String(value));
  };

  const handleStart = () => {
    const parsedMin = parseInt(min, 10);
    const parsedMax = parseInt(max, 10);
    if (isNaN(parsedMin) || isNaN(parsedMax) || parsedMin >= parsedMax) {
      setError('Set a valid range');
      return;
    }

    let mode = activePreset;
    if (selected === 'custom') {
      const guesses = parseInt(customGuessLimit, 10);
      const timer = customTimer === '' ? null : parseInt(customTimer, 10);
      if (customGuessEnabled && (isNaN(guesses) || guesses < 1)) {
        setError('Set at least 1 guess');
        return;
      }
      if (customTimerEnabled && (timer === null || isNaN(timer) || timer < 5)) {
        setError('Timer must be at least 5 seconds');
        return;
      }
      mode = {
        ...activePreset,
        min: parsedMin,
        max: parsedMax,
        maxGuesses: customGuessEnabled ? guesses : null,
        timerSeconds: customTimerEnabled ? timer : null,
      };
    } else {
      mode = { ...activePreset, min: parsedMin, max: parsedMax };
    }

    sound.resume();
    sound.play('start');
    onStart(mode);
  };

  return (
    <div className="relative flex min-h-dvh flex-col items-center overflow-hidden px-5 py-6">
      <MemphisShapes count={10} />
      <div className="relative z-10 w-full max-w-2xl">
        <div className="mb-5 flex justify-end gap-2">
          <button onClick={onToggleMusic} className="rounded-xl border-[3px] border-ink-900 bg-white p-2.5 shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none" title="Toggle music">
            {musicEnabled ? <Music className="h-4 w-4" /> : <Music2 className="h-4 w-4 text-ink-300" />}
          </button>
          <button onClick={onToggleMute} className="rounded-xl border-[3px] border-ink-900 bg-white p-2.5 shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none" title="Toggle sound">
            {muted ? <VolumeX className="h-4 w-4 text-ink-300" /> : <Volume2 className="h-4 w-4" />}
          </button>
          <button onClick={onShowStats} className="rounded-xl border-[3px] border-ink-900 bg-memphis-teal p-2.5 shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none" title="Statistics">
            <BarChart3 className="h-4 w-4" />
          </button>
        </div>

        <div className="mb-7 flex flex-col items-center text-center animate-slide-up">
          <div className="mb-4"><Mascot mood="idle" size={88} /></div>
          <div className="mb-2 inline-flex items-center gap-2 rounded-lg border-[3px] border-ink-900 bg-ink-900 px-3 py-1 font-display text-[10px] font-black uppercase tracking-widest text-memphis-yellow shadow-memphis-sm">
            <SlidersHorizontal className="h-3.5 w-3.5" /> Game Setup
          </div>
          <h1 className="font-display text-4xl font-black uppercase tracking-tight text-ink-900 sm:text-5xl" style={{ textShadow: '4px 4px 0px #FF6B6B' }}>
            Select Mode &amp; Range
          </h1>
          <p className="mt-2 max-w-md font-display text-xs font-bold uppercase tracking-widest text-ink-500">
            Choose a range and a challenge mode with limits and timers.
          </p>
          {bestScore !== null && (
            <div className="mt-3 rounded-lg border-[3px] border-ink-900 bg-memphis-yellow px-4 py-1.5 font-display text-xs font-black uppercase shadow-memphis-sm">
              Best score <span className="font-mono">{bestScore}</span>
            </div>
          )}
        </div>

        {/* Number range panel */}
        <section className="mb-4 rounded-2xl border-[3px] border-ink-900 bg-white p-5 shadow-memphis-lg">
          <div className="mb-4 flex items-center justify-between border-b-[3px] border-ink-900 pb-3">
            <div className="flex items-center gap-2">
              <div className="flex h-6 w-6 items-center justify-center rounded bg-ink-900 text-memphis-yellow"><Hash className="h-4 w-4" /></div>
              <div>
                <h2 className="font-display text-sm font-black uppercase">Number Range</h2>
                <p className="font-mono text-[10px] text-ink-500">{Math.max(0, parsedNumber(max) - parsedNumber(min) + 1).toLocaleString()} numbers · optimal search {Math.ceil(Math.log2(Math.max(2, parsedNumber(max) - parsedNumber(min) + 1)))} guesses</p>
              </div>
            </div>
            <div className="rounded border-2 border-ink-900 bg-memphis-cream px-2 py-1 font-mono text-xs font-bold">{min} — {max}</div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <label className="font-display text-[10px] font-black uppercase tracking-wide text-ink-600">Minimum (from)
              <input type="number" value={min} onChange={(e) => setMin(e.target.value)} className="mt-1.5 w-full rounded-lg border-[3px] border-ink-900 bg-memphis-cream px-3 py-2.5 font-mono text-lg font-bold outline-none focus:bg-memphis-yellow" />
            </label>
            <label className="font-display text-[10px] font-black uppercase tracking-wide text-ink-600">Maximum (to)
              <input type="number" value={max} onChange={(e) => setMax(e.target.value)} className="mt-1.5 w-full rounded-lg border-[3px] border-ink-900 bg-memphis-cream px-3 py-2.5 font-mono text-lg font-bold outline-none focus:bg-memphis-yellow" />
            </label>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="font-display text-[10px] font-black uppercase text-ink-500">Quick ranges</span>
            {QUICK_RANGES.map((value) => (
              <button key={value} onClick={() => setQuickRange(value)} className={`rounded border-2 border-ink-900 px-2.5 py-1 font-mono text-xs font-bold shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none ${max === String(value) && min === '1' ? 'bg-ink-900 text-memphis-yellow' : 'bg-white hover:bg-memphis-yellow'}`}>
                1–{value.toLocaleString()}
              </button>
            ))}
          </div>
        </section>

        {/* Mode grid */}
        <section className="mb-4">
          <div className="mb-2 flex items-center gap-2 font-display text-xs font-black uppercase tracking-widest text-ink-600"><ZapIcon /> Select Game Mode</div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {RANGE_PRESETS.map((mode) => {
              const isActive = selected === mode.id;
              return (
                <button key={mode.id} onClick={() => selectMode(mode)} className={`flex min-h-[142px] flex-col items-start rounded-xl border-[3px] border-ink-900 p-4 text-left transition-all duration-200 ${isActive ? 'shadow-memphis-lg -translate-y-1' : 'bg-white shadow-memphis hover:-translate-y-0.5'}`} style={{ backgroundColor: isActive ? MODE_COLORS[mode.id] : '#FFFFFF' }}>
                  <div className="mb-3 flex w-full items-start justify-between gap-2"><mode.icon className="h-6 w-6" /><span className="rounded border-2 border-ink-900 bg-white px-1.5 py-0.5 font-display text-[9px] font-black uppercase">{mode.id === 'custom' ? 'Custom' : mode.id === 'speedrun' ? 'Fast-paced' : mode.id === 'hardcore' ? 'High stakes' : mode.id === 'strict' ? 'Precision' : mode.id === 'relaxed' ? 'Casual' : 'Popular'}</span></div>
                  <span className="font-display text-sm font-black uppercase leading-tight">{mode.label}</span>
                  <span className="mt-1 font-sans text-xs font-medium text-ink-600">{mode.description}</span>
                  <span className="mt-auto flex items-center gap-1 rounded border-2 border-ink-900 bg-white px-2 py-1 font-display text-[9px] font-black uppercase"><RuleIcon mode={mode} />{formatRules(mode)}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Custom settings */}
        {selected === 'custom' && (
          <section className="mb-4 animate-slide-up rounded-2xl border-[3px] border-ink-900 bg-white p-5 shadow-memphis-lg">
            <div className="mb-4 flex items-center gap-2 border-b-[3px] border-ink-900 pb-3 font-display text-xs font-black uppercase tracking-widest"><SlidersHorizontal className="h-4 w-4" /> Custom Limits &amp; Timer Settings</div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-lg border-2 border-ink-900 bg-memphis-cream p-3">
                <label className="flex items-center gap-2 font-display text-xs font-black uppercase"><input type="checkbox" checked={customGuessEnabled} onChange={(e) => setCustomGuessEnabled(e.target.checked)} className="h-4 w-4 accent-black" /> Enable guess limit</label>
                <label className="mt-3 flex items-center justify-between gap-2 font-display text-[10px] font-bold uppercase text-ink-500">Max attempts<input type="number" min="1" value={customGuessLimit} disabled={!customGuessEnabled} onChange={(e) => setCustomGuessLimit(e.target.value)} className="w-20 rounded border-2 border-ink-900 bg-white px-2 py-1 font-mono text-sm font-bold disabled:opacity-40" /></label>
              </div>
              <div className="rounded-lg border-2 border-ink-900 bg-memphis-cream p-3">
                <label className="flex items-center gap-2 font-display text-xs font-black uppercase"><input type="checkbox" checked={customTimerEnabled} onChange={(e) => setCustomTimerEnabled(e.target.checked)} className="h-4 w-4 accent-black" /><Timer className="h-4 w-4" /> Enable timer</label>
                <label className="mt-3 flex items-center justify-between gap-2 font-display text-[10px] font-bold uppercase text-ink-500">Seconds<input type="number" min="5" value={customTimer} disabled={!customTimerEnabled} placeholder="45" onChange={(e) => setCustomTimer(e.target.value)} className="w-20 rounded border-2 border-ink-900 bg-white px-2 py-1 font-mono text-sm font-bold disabled:opacity-40" /></label>
              </div>
            </div>
          </section>
        )}

        {error && <p className="mb-3 text-center font-display text-sm font-black uppercase text-memphis-coral">{error}</p>}
        <button onClick={handleStart} className="group flex w-full items-center justify-center gap-2 rounded-2xl border-[3px] border-ink-900 bg-ink-900 px-6 py-5 font-display text-lg font-black uppercase tracking-wide text-memphis-cream shadow-memphis-lg transition-all hover:-translate-y-0.5 active:translate-x-[4px] active:translate-y-[4px] active:shadow-none">
          Start Game <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
        </button>
      </div>
    </div>
  );
}

function parsedNumber(value: string): number {
  const result = parseInt(value, 10);
  return Number.isFinite(result) ? result : 0;
}

function formatRules(mode: RangePreset): string {
  if (mode.maxGuesses !== null && mode.timerSeconds !== null) return `${mode.maxGuesses} guesses & ${mode.timerSeconds}s`;
  if (mode.maxGuesses !== null) return `Limit: ${mode.maxGuesses} guesses`;
  if (mode.timerSeconds !== null) return `Timer: ${mode.timerSeconds} seconds`;
  return 'Unlimited & no timer';
}

function RuleIcon({ mode }: { mode: RangePreset }) {
  if (mode.timerSeconds !== null) return <Timer className="h-3 w-3" />;
  return <Hash className="h-3 w-3" />;
}

function ZapIcon() {
  return <span className="text-memphis-coral">↯</span>;
}
