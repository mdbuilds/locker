import {
  type GameStats,
  averageGuesses,
  winRate,
  mostFrequentDifficulty,
  averageScore,
  resetStats,
} from '@/game/stats';
import { RANGE_PRESETS } from '@/game/types';
import { MemphisShapes } from '@/components/MemphisShapes';
import {
  Gamepad2,
  Target,
  TrendingUp,
  Trophy,
  Gauge,
  Crown,
  Trash2,
  ArrowLeft,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface StatsScreenProps {
  stats: GameStats;
  onBack: () => void;
  onReset: () => void;
}

const CARD_COLORS = [
  '#FFD93D',
  '#4ECDC4',
  '#FF8FAB',
  '#C5E063',
  '#6BC5F2',
  '#FF9F43',
  '#FF6B6B',
];

export function StatsScreen({ stats, onBack, onReset }: StatsScreenProps) {
  const avgGuesses = averageGuesses(stats);
  const wr = winRate(stats);
  const topDiff = mostFrequentDifficulty(stats);
  const avgScore = averageScore(stats);
  const topDiffPreset = RANGE_PRESETS.find((p) => p.id === topDiff);

  const cards: StatCard[] = [
    { icon: Gamepad2, label: 'Games', value: String(stats.totalGames) },
    { icon: Target, label: 'Avg Guesses', value: avgGuesses > 0 ? avgGuesses.toFixed(1) : '—' },
    { icon: TrendingUp, label: 'Win Rate', value: stats.totalGames > 0 ? `${Math.round(wr)}%` : '—' },
    { icon: Trophy, label: 'Best Score', value: stats.bestScore !== null ? String(stats.bestScore) : '—' },
    { icon: Gauge, label: 'Fewest', value: stats.fewestGuesses !== null ? String(stats.fewestGuesses) : '—' },
    { icon: Crown, label: 'Top Diff', value: topDiffPreset ? topDiffPreset.label : '—', iconRef: topDiffPreset?.icon },
    { icon: TrendingUp, label: 'Avg Score', value: avgScore > 0 ? String(avgScore) : '—' },
  ];

  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden px-5 py-6">
      <MemphisShapes count={6} />

      <div className="relative z-10 mx-auto w-full max-w-lg">
        {/* Top bar */}
        <div className="mb-8 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 rounded-lg border-[3px] border-ink-900 bg-white px-3 py-1.5 font-display text-sm font-black uppercase text-ink-900 shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </button>
          <h1
            className="font-display text-2xl font-black uppercase tracking-tight"
            style={{ textShadow: '3px 3px 0px #4ECDC4' }}
          >
            Stats
          </h1>
          <button
            onClick={onReset}
            className="rounded-lg border-[3px] border-ink-900 bg-white p-2 shadow-memphis-sm transition-all hover:bg-memphis-coral hover:text-white active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
            title="Reset stats"
          >
            <Trash2 className="h-4 w-4 text-ink-600" />
          </button>
        </div>

        {/* Stat grid */}
        <div className="grid grid-cols-2 gap-3">
          {cards.map((card, i) => (
            <div
              key={card.label}
              className="animate-slide-up rounded-2xl border-[3px] border-ink-900 p-5 shadow-memphis"
              style={{
                backgroundColor: CARD_COLORS[i % CARD_COLORS.length],
                animationDelay: `${i * 50}ms`,
              }}
            >
              <div className="mb-3 flex items-center gap-2">
                {card.iconRef ? (
                  <card.iconRef className="h-5 w-5 text-ink-800" />
                ) : (
                  <card.icon className="h-5 w-5 text-ink-800" />
                )}
                <span className="font-display text-[10px] font-black uppercase tracking-widest text-ink-700">
                  {card.label}
                </span>
              </div>
              <div className="font-display text-3xl font-black text-ink-900">
                {card.value}
              </div>
            </div>
          ))}
        </div>

        {/* Difficulty distribution */}
        <div
          className="mt-3 animate-slide-up rounded-2xl border-[3px] border-ink-900 bg-white p-5 shadow-memphis"
          style={{ animationDelay: '350ms' }}
        >
          <h2 className="mb-4 font-display text-xs font-black uppercase tracking-widest text-ink-500">
            Difficulty Breakdown
          </h2>
          <div className="space-y-3">
            {RANGE_PRESETS.map((preset) => {
              const count = stats.difficultyCounts[preset.id] ?? 0;
              const pct =
                stats.totalGames > 0
                  ? (count / stats.totalGames) * 100
                  : 0;
              return (
                <div key={preset.id} className="flex items-center gap-3">
                  <preset.icon className="h-4 w-4 shrink-0 text-ink-700" />
                  <span className="w-16 font-display text-sm font-bold uppercase text-ink-700">
                    {preset.label}
                  </span>
                  <div className="relative h-3 flex-1 overflow-hidden rounded-full border-2 border-ink-900 bg-ink-50">
                    <div
                      className="absolute inset-y-0 left-0 rounded-full bg-ink-900 transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="w-6 text-right font-mono text-sm font-bold text-ink-600">
                    {count}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Score trend */}
        {stats.scores.length > 1 && (
          <div
            className="mt-3 animate-slide-up rounded-2xl border-[3px] border-ink-900 bg-white p-5 shadow-memphis"
            style={{ animationDelay: '400ms' }}
          >
            <h2 className="mb-4 font-display text-xs font-black uppercase tracking-widest text-ink-500">
              Score Trend
            </h2>
            <ScoreTrend scores={stats.scores} />
          </div>
        )}

        {stats.totalGames === 0 && (
          <p className="mt-6 text-center font-display text-sm font-bold uppercase text-ink-300">
            Play a game to see your stats here
          </p>
        )}
      </div>
    </div>
  );
}

interface StatCard {
  icon: LucideIcon;
  label: string;
  value: string;
  iconRef?: LucideIcon;
}

function ScoreTrend({ scores }: { scores: number[] }) {
  const max = Math.max(...scores);
  const min = Math.min(...scores);
  const range = Math.max(1, max - min);
  const colors = ['#FF6B6B', '#FFD93D', '#4ECDC4', '#FF8FAB', '#6BC5F2', '#C5E063', '#FF9F43'];
  return (
    <div className="flex h-20 items-end gap-1">
      {scores.map((s, i) => {
        const height = ((s - min) / range) * 100;
        return (
          <div
            key={i}
            className="flex-1 rounded-t border-2 border-ink-900 transition-all duration-300"
            style={{
              height: `${Math.max(12, height)}%`,
              backgroundColor: colors[i % colors.length],
            }}
            title={`Game ${i + 1}: ${s}`}
          />
        );
      })}
    </div>
  );
}
