import { Mascot } from '@/components/Mascot';
import { MemphisShapes } from '@/components/MemphisShapes';
import { RotateCcw, Home, BarChart3, Skull } from 'lucide-react';
import { useEffect } from 'react';
import { sound } from '@/game/sound';

interface LoseScreenProps {
  secret: number;
  attempts: number;
  reason: 'time' | 'guesses';
  onPlayAgain: () => void;
  onHome: () => void;
  onShowStats: () => void;
}

export function LoseScreen({
  secret,
  attempts,
  reason,
  onPlayAgain,
  onHome,
  onShowStats,
}: LoseScreenProps) {
  useEffect(() => {
    sound.play('incorrect');
  }, []);

  return (
    <div className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden px-5 py-8">
      <MemphisShapes count={8} />

      <div className="relative z-10 w-full max-w-sm text-center">
        <div className="mb-6 flex justify-center animate-pop-in">
          <Mascot mood="too-high" size={110} />
        </div>

        <h1
          className="mb-2 animate-slide-up font-display text-4xl font-black uppercase tracking-tight"
          style={{ textShadow: '4px 4px 0px #FF6B6B' }}
        >
          {reason === 'time' ? "Time's Up!" : 'Out of Guesses!'}
        </h1>
        <p className="mb-6 animate-slide-up font-display text-sm font-black uppercase tracking-widest text-ink-500" style={{ animationDelay: '100ms' }}>
          The number was
        </p>

        <div
          className="mb-6 animate-pop-in rounded-3xl border-[4px] border-ink-900 bg-ink-900 p-8 shadow-memphis-lg"
          style={{ animationDelay: '200ms' }}
        >
          <div className="mb-2 flex items-center justify-center gap-1.5 font-display text-xs font-black uppercase tracking-widest text-memphis-coral">
            <Skull className="h-3.5 w-3.5" />
            Missed
          </div>
          <div className="font-mono text-5xl font-bold text-memphis-cream sm:text-6xl">
            {secret.toLocaleString()}
          </div>
        </div>

        <div
          className="mb-6 grid grid-cols-1 gap-3 animate-slide-up"
          style={{ animationDelay: '300ms' }}
        >
          <div className="rounded-2xl border-[3px] border-ink-900 bg-white p-4 shadow-memphis-sm">
            <div className="font-display text-[10px] font-black uppercase tracking-widest text-ink-400">Guesses Used</div>
            <div className="font-display text-2xl font-black">{attempts}</div>
          </div>
        </div>

        <div
          className="flex flex-col gap-3 animate-slide-up"
          style={{ animationDelay: '400ms' }}
        >
          <button
            onClick={onPlayAgain}
            className="group flex w-full items-center justify-center gap-2 rounded-2xl border-[3px] border-ink-900 bg-memphis-coral px-6 py-4 font-display text-base font-black uppercase tracking-wide text-ink-900 shadow-memphis-lg transition-all hover:-translate-y-0.5 active:translate-x-[4px] active:translate-y-[4px] active:shadow-none"
          >
            <RotateCcw className="h-5 w-5 transition-transform duration-300 group-hover:-rotate-180" />
            Try Again
          </button>
          <div className="flex gap-3">
            <button
              onClick={onHome}
              className="flex flex-1 items-center justify-center gap-2 rounded-2xl border-[3px] border-ink-900 bg-white px-4 py-3 font-display text-sm font-black uppercase shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
            >
              <Home className="h-4 w-4" />
              Home
            </button>
            <button
              onClick={onShowStats}
              className="flex flex-1 items-center justify-center gap-2 rounded-2xl border-[3px] border-ink-900 bg-memphis-blue px-4 py-3 font-display text-sm font-black uppercase shadow-memphis-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
            >
              <BarChart3 className="h-4 w-4" />
              Stats
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
