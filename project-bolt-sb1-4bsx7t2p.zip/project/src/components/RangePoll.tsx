import type { GuessEntry } from '@/game/types';
import { computeHintRange } from '@/game/types';

interface RangePollProps {
  history: GuessEntry[];
  min: number;
  max: number;
  secret: number;
}

/**
 * Visual "poll" of where the secret number could be.
 * Shows a horizontal bar from min to max. Eliminated ranges are greyed out.
 * The remaining candidate range is highlighted with a Memphis color.
 * Each guess is marked on the bar with an up/down arrow.
 */
export function RangePoll({ history, min, max }: RangePollProps) {
  const { low, high } = computeHintRange(history, min, max);
  const range = max - min;
  const safeRange = Math.max(1, range);

  const candidateLeft = ((low - min) / safeRange) * 100;
  const candidateWidth = ((high - low) / safeRange) * 100;

  return (
    <div className="rounded-2xl border-[3px] border-ink-900 bg-white p-4 shadow-memphis-sm">
      <div className="mb-2 flex items-center justify-between">
        <span className="font-display text-[10px] font-black uppercase tracking-widest text-ink-500">
          Candidate Range
        </span>
        <span className="font-mono text-xs font-bold text-ink-700">
          {low}–{high.toLocaleString()}
        </span>
      </div>

      {/* The bar */}
      <div className="relative h-10 overflow-hidden rounded-lg border-[3px] border-ink-900 bg-ink-50">
        {/* Eliminated left zone */}
        {candidateLeft > 0 && (
          <div
            className="absolute inset-y-0 left-0 bg-stripes-diag opacity-20"
            style={{ width: `${candidateLeft}%` }}
          />
        )}
        {/* Candidate zone */}
        <div
          className="absolute inset-y-0 bg-memphis-teal/40 transition-all duration-500"
          style={{ left: `${candidateLeft}%`, width: `${candidateWidth}%` }}
        >
          <div className="flex h-full items-center justify-center">
            <span className="font-display text-[10px] font-black uppercase text-ink-700">
              {high - low < 4 ? 'Almost!' : ''}
            </span>
          </div>
        </div>
        {/* Eliminated right zone */}
        {candidateLeft + candidateWidth < 100 && (
          <div
            className="absolute inset-y-0 right-0 bg-stripes-diag opacity-20"
            style={{ width: `${100 - candidateLeft - candidateWidth}%` }}
          />
        )}

        {/* Guess markers */}
        {history.map((entry) => {
          const pos = ((entry.value - min) / safeRange) * 100;
          const clamped = Math.max(0, Math.min(100, pos));
          return (
            <div
              key={entry.attempt}
              className="absolute top-1/2 -translate-y-1/2 animate-pop-in"
              style={{ left: `${clamped}%`, transform: 'translate(-50%, -50%)' }}
            >
              <div
                className={`flex h-6 w-6 items-center justify-center rounded-full border-2 border-ink-900 text-ink-900 ${
                  entry.feedback === 'too-low'
                    ? 'bg-memphis-yellow'
                    : entry.feedback === 'too-high'
                      ? 'bg-memphis-pink'
                      : 'bg-memphis-lime'
                }`}
                title={`Guess ${entry.attempt}: ${entry.value}`}
              >
                <span className="font-mono text-[8px] font-bold">{entry.attempt}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Min / Max labels */}
      <div className="mt-1.5 flex justify-between font-mono text-[10px] text-ink-400">
        <span>{min}</span>
        <span>{max.toLocaleString()}</span>
      </div>
    </div>
  );
}
