import { useMemo } from 'react';

const MEMPHIS_COLORS = [
  '#FF6B6B',
  '#FFD93D',
  '#4ECDC4',
  '#FF8FAB',
  '#6BC5F2',
  '#C5E063',
  '#FF9F43',
  '#0a0a0a',
];

type PieceShape = 'circle' | 'square' | 'triangle' | 'rect' | 'cross';

interface ConfettiPiece {
  id: number;
  left: number;
  delay: number;
  duration: number;
  size: number;
  color: string;
  shape: PieceShape;
}

export function Confetti({ count = 80 }: { count?: number }) {
  const pieces = useMemo<ConfettiPiece[]>(() => {
    const shapes: PieceShape[] = ['circle', 'square', 'triangle', 'rect', 'cross'];
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 0.6,
      duration: 2 + Math.random() * 2.5,
      size: 8 + Math.random() * 14,
      color: MEMPHIS_COLORS[Math.floor(Math.random() * MEMPHIS_COLORS.length)],
      shape: shapes[Math.floor(Math.random() * shapes.length)],
    }));
  }, [count]);

  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {pieces.map((p) => (
        <div
          key={p.id}
          className="absolute top-0 animate-confetti-fall"
          style={{
            left: `${p.left}%`,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
          }}
        >
          <Piece piece={p} />
        </div>
      ))}
    </div>
  );
}

function Piece({ piece }: { piece: ConfettiPiece }) {
  const { shape, color, size } = piece;

  if (shape === 'circle') {
    return (
      <div
        style={{
          width: size,
          height: size,
          backgroundColor: color,
          border: '2px solid #0a0a0a',
          borderRadius: '50%',
        }}
      />
    );
  }

  if (shape === 'square') {
    return (
      <div
        style={{
          width: size,
          height: size,
          backgroundColor: color,
          border: '2px solid #0a0a0a',
          borderRadius: '3px',
        }}
      />
    );
  }

  if (shape === 'rect') {
    return (
      <div
        style={{
          width: size * 1.4,
          height: size * 0.5,
          backgroundColor: color,
          border: '2px solid #0a0a0a',
          borderRadius: '3px',
        }}
      />
    );
  }

  if (shape === 'triangle') {
    return (
      <svg width={size} height={size} viewBox="0 0 100 100">
        <polygon
          points="50,8 92,88 8,88"
          fill={color}
          stroke="#0a0a0a"
          strokeWidth="8"
          strokeLinejoin="round"
        />
      </svg>
    );
  }

  // cross
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <rect x="40" y="5" width="20" height="90" fill={color} stroke="#0a0a0a" strokeWidth="8" rx="4" />
      <rect x="5" y="40" width="90" height="20" fill={color} stroke="#0a0a0a" strokeWidth="8" rx="4" />
    </svg>
  );
}
