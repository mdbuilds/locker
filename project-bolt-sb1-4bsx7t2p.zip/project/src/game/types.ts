import type { LucideIcon } from 'lucide-react';
import { Leaf, Flame, Mountain, Target, Zap, SlidersHorizontal } from 'lucide-react';

export type Difficulty = 'standard' | 'strict' | 'speedrun' | 'hardcore' | 'relaxed' | 'custom';

export type GamePhase = 'setup' | 'playing' | 'won' | 'lost';

export type GuessFeedback = 'too-low' | 'too-high' | 'correct';

export interface RangePreset {
  id: Difficulty;
  label: string;
  description: string;
  min: number;
  max: number;
  maxGuesses: number | null;
  timerSeconds: number | null;
  icon: LucideIcon;
}

export interface GuessEntry {
  value: number;
  feedback: GuessFeedback;
  attempt: number;
}

export const RANGE_PRESETS: RangePreset[] = [
  { id: 'standard', label: 'Standard', description: '10 guesses', min: 1, max: 100, maxGuesses: 10, timerSeconds: null, icon: Target },
  { id: 'strict', label: 'Strict / Optimal', description: '7 guesses only', min: 1, max: 100, maxGuesses: 7, timerSeconds: null, icon: Zap },
  { id: 'speedrun', label: 'Speedrun Blitz', description: '45-second timer', min: 1, max: 100, maxGuesses: null, timerSeconds: 45, icon: Flame },
  { id: 'hardcore', label: 'Hardcore', description: '7 guesses · 45s', min: 1, max: 100, maxGuesses: 7, timerSeconds: 45, icon: Mountain },
  { id: 'relaxed', label: 'Relaxed', description: 'Unlimited', min: 1, max: 100, maxGuesses: null, timerSeconds: null, icon: Leaf },
  { id: 'custom', label: 'Custom Rules', description: 'Your rules', min: 1, max: 100, maxGuesses: 8, timerSeconds: null, icon: SlidersHorizontal },
];

export function generateSecret(min: number, max: number): number {
  const lo = Math.min(min, max);
  const hi = Math.max(min, max);
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

export function scoreForAttempts(attempts: number, rangeSize: number): number {
  const ideal = Math.max(1, Math.ceil(Math.log2(rangeSize)));
  const efficiency = ideal / attempts;
  const base = 1000;
  const score = Math.round(base * efficiency * (1 + Math.log10(rangeSize) / 4));
  return Math.max(10, Math.min(1000, score));
}

export function attemptsToStars(attempts: number, rangeSize: number): number {
  const ideal = Math.max(1, Math.ceil(Math.log2(rangeSize)));
  const ratio = ideal / attempts;
  if (ratio >= 0.95) return 3;
  if (ratio >= 0.7) return 2;
  return 1;
}

/** Narrow the remaining possible range based on guess history. */
export function computeHintRange(
  history: GuessEntry[],
  min: number,
  max: number,
): { low: number; high: number } {
  let low = min;
  let high = max;
  for (const entry of history) {
    if (entry.feedback === 'too-low') {
      low = Math.max(low, entry.value + 1);
    } else if (entry.feedback === 'too-high') {
      high = Math.min(high, entry.value - 1);
    }
  }
  return { low, high };
}
