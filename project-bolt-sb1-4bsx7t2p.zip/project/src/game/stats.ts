import type { Difficulty } from './types';

export interface GameStats {
  totalGames: number;
  totalGuesses: number;
  totalWins: number;
  bestScore: number | null;
  fewestGuesses: number | null;
  difficultyCounts: Record<string, number>;
  scores: number[];
}

const STORAGE_KEY = 'guessit-stats-v1';

const empty: GameStats = {
  totalGames: 0,
  totalGuesses: 0,
  totalWins: 0,
  bestScore: null,
  fewestGuesses: null,
  difficultyCounts: {},
  scores: [],
};

export function loadStats(): GameStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...empty };
    const parsed = JSON.parse(raw) as Partial<GameStats>;
    return {
      ...empty,
      ...parsed,
      difficultyCounts: parsed.difficultyCounts ?? {},
      scores: parsed.scores ?? [],
    };
  } catch {
    return { ...empty };
  }
}

export function saveStats(stats: GameStats) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch {
    // ignore quota errors
  }
}

export interface RecordGameResult {
  stats: GameStats;
  isNewBestScore: boolean;
  isNewFewest: boolean;
}

export function recordGame(
  prev: GameStats,
  result: { won: boolean; attempts: number; score: number; difficulty: Difficulty },
): RecordGameResult {
  const difficultyCounts = { ...prev.difficultyCounts };
  difficultyCounts[result.difficulty] = (difficultyCounts[result.difficulty] ?? 0) + 1;

  const stats: GameStats = {
    totalGames: prev.totalGames + 1,
    totalGuesses: prev.totalGuesses + result.attempts,
    totalWins: prev.totalWins + (result.won ? 1 : 0),
    bestScore:
      result.won && (prev.bestScore === null || result.score > prev.bestScore)
        ? result.score
        : prev.bestScore,
    fewestGuesses:
      result.won &&
      (prev.fewestGuesses === null || result.attempts < prev.fewestGuesses)
        ? result.attempts
        : prev.fewestGuesses,
    difficultyCounts,
    scores:
      result.won && result.score > 0
        ? [...prev.scores, result.score].slice(-50)
        : prev.scores,
  };

  return {
    stats,
    isNewBestScore:
      result.won &&
      (prev.bestScore === null || result.score > prev.bestScore),
    isNewFewest:
      result.won &&
      (prev.fewestGuesses === null || result.attempts < prev.fewestGuesses),
  };
}

export function averageGuesses(stats: GameStats): number {
  if (stats.totalGames === 0) return 0;
  return stats.totalGuesses / stats.totalGames;
}

export function winRate(stats: GameStats): number {
  if (stats.totalGames === 0) return 0;
  return (stats.totalWins / stats.totalGames) * 100;
}

export function mostFrequentDifficulty(stats: GameStats): Difficulty | null {
  let best: Difficulty | null = null;
  let bestCount = 0;
  for (const [key, count] of Object.entries(stats.difficultyCounts)) {
    if (count > bestCount) {
      bestCount = count;
      best = key as Difficulty;
    }
  }
  return best;
}

export function averageScore(stats: GameStats): number {
  if (stats.scores.length === 0) return 0;
  return Math.round(
    stats.scores.reduce((a, b) => a + b, 0) / stats.scores.length,
  );
}

export function resetStats(): GameStats {
  const fresh = { ...empty };
  saveStats(fresh);
  return fresh;
}
