/**
 * Web Audio sound engine for GuessIt.
 * All sounds are synthesized procedurally — no audio files needed.
 * Black & white anthropomorphic theme: clean tones, soft pads, percussive blips.
 */

type SfxName = 'correct' | 'incorrect' | 'hint' | 'win' | 'click' | 'start';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicTimer: number | null = null;
  private musicPlaying = false;
  private musicStep = 0;

  private _muted = false;
  private _musicEnabled = true;

  get muted() {
    return this._muted;
  }

  get musicEnabled() {
    return this._musicEnabled;
  }

  private ensureContext() {
    if (this.ctx) return;
    const Ctor =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    this.ctx = new Ctor();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.6;
    this.masterGain.connect(this.ctx.destination);

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = 0.7;
    this.sfxGain.connect(this.masterGain);

    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = 0.12;
    this.musicGain.connect(this.masterGain);
  }

  /** Must be called from a user gesture to unlock audio on mobile/Safari. */
  resume() {
    this.ensureContext();
    if (this.ctx && this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
  }

  setMuted(muted: boolean) {
    this._muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        muted ? 0 : 0.6,
        this.ctx.currentTime,
        0.05,
      );
    }
  }

  setMusicEnabled(enabled: boolean) {
    this._musicEnabled = enabled;
    if (enabled) {
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  // ── SFX ──────────────────────────────────────────────

  play(name: SfxName) {
    this.ensureContext();
    if (!this.ctx || !this.sfxGain) return;
    if (this._muted) return;
    const now = this.ctx.currentTime;
    switch (name) {
      case 'correct':
        this.playCorrect(now);
        break;
      case 'incorrect':
        this.playIncorrect(now);
        break;
      case 'hint':
        this.playHint(now);
        break;
      case 'win':
        this.playWin(now);
        break;
      case 'click':
        this.playBlip(now, 600, 0.06, 0.08);
        break;
      case 'start':
        this.playStart(now);
        break;
    }
  }

  private playBlip(
    time: number,
    freq: number,
    duration: number,
    volume: number,
    type: OscillatorType = 'sine',
  ) {
    if (!this.ctx || !this.sfxGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, time);
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(volume, time + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(time);
    osc.stop(time + duration + 0.05);
  }

  private playCorrect(time: number) {
    // Bright ascending arpeggio: C-E-G-C
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((f, i) => {
      this.playBlip(time + i * 0.08, f, 0.18, 0.12, 'triangle');
    });
  }

  private playIncorrect(time: number) {
    // Soft neutral two-tone descending blip
    this.playBlip(time, 440, 0.1, 0.06, 'sine');
    this.playBlip(time + 0.08, 330, 0.12, 0.05, 'sine');
  }

  private playHint(time: number) {
    // Subtle shimmer — two quiet high partials
    this.playBlip(time, 880, 0.15, 0.035, 'sine');
    this.playBlip(time + 0.04, 1320, 0.2, 0.025, 'sine');
  }

  private playWin(time: number) {
    // Celebratory fanfare: C-E-G-C + sparkle
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51];
    notes.forEach((f, i) => {
      this.playBlip(time + i * 0.1, f, 0.25, 0.1, 'triangle');
    });
    // Sparkle tail
    this.playBlip(time + 0.5, 1567.98, 0.4, 0.06, 'sine');
    this.playBlip(time + 0.55, 2093, 0.4, 0.04, 'sine');
  }

  private playStart(time: number) {
    this.playBlip(time, 392, 0.08, 0.06, 'triangle');
    this.playBlip(time + 0.06, 523.25, 0.12, 0.07, 'triangle');
  }

  // ── Ambient background music ──────────────────────────
  // A slow, minimalist loop in a minor key — fits the monochrome,
  // anthropomorphic vibe. Generated with oscillators + a soft pad.

  startMusic() {
    if (!this._musicEnabled || this.musicPlaying) return;
    this.ensureContext();
    if (!this.ctx || !this.musicGain) return;
    this.musicPlaying = true;
    this.musicStep = 0;

    // A minor pentatonic-ish progression (A, C, D, E, G octaves)
    const melody = [
      220.0, 261.63, 293.66, 329.63, 0, 293.66, 261.63, 220.0,
      196.0, 246.94, 293.66, 329.63, 0, 329.63, 293.66, 246.94,
    ];
    const bass = [110.0, 0, 0, 0, 98.0, 0, 0, 0, 87.31, 0, 0, 0, 98.0, 0, 0, 0];
    const stepDuration = 0.42;

    const playStep = () => {
      if (!this.ctx || !this.musicGain || !this.musicPlaying) return;
      const time = this.ctx.currentTime;
      const step = this.musicStep % melody.length;

      const note = melody[step];
      if (note > 0) {
        this.playMusicNote(time, note, stepDuration * 0.9, 0.06, 'sine');
      }

      const bassNote = bass[step];
      if (bassNote > 0) {
        this.playMusicNote(time, bassNote, stepDuration * 2, 0.05, 'triangle');
      }

      // Soft pad chord every 4 steps
      if (step % 4 === 0) {
        const chordRoot = bassNote > 0 ? bassNote : 110;
        this.playMusicNote(time, chordRoot * 2, stepDuration * 3.5, 0.025, 'sine');
        this.playMusicNote(time, chordRoot * 3, stepDuration * 3.5, 0.02, 'sine');
      }

      this.musicStep++;
      this.musicTimer = window.setTimeout(playStep, stepDuration * 1000);
    };

    playStep();
  }

  private playMusicNote(
    time: number,
    freq: number,
    duration: number,
    volume: number,
    type: OscillatorType,
  ) {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, time);
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(volume, time + 0.08);
    gain.gain.linearRampToValueAtTime(volume * 0.7, time + duration * 0.6);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    osc.connect(gain);
    gain.connect(this.musicGain);
    osc.start(time);
    osc.stop(time + duration + 0.1);
  }

  stopMusic() {
    this.musicPlaying = false;
    if (this.musicTimer) {
      clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }
}

export const sound = new SoundEngine();
export type { SfxName };
