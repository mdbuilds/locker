/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Archivo Black"', 'system-ui', 'sans-serif'],
        sans: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        mono: ['"Space Mono"', 'ui-monospace', 'monospace'],
      },
      colors: {
        ink: {
          DEFAULT: '#0a0a0a',
          900: '#0a0a0a',
          800: '#1a1a1a',
          700: '#2a2a2a',
          600: '#3a3a3a',
          500: '#525252',
          400: '#737373',
          300: '#a3a3a3',
          200: '#d4d4d4',
          100: '#e8e8e8',
          50: '#f5f5f5',
        },
        memphis: {
          coral: '#FF6B6B',
          yellow: '#FFD93D',
          teal: '#4ECDC4',
          pink: '#FF8FAB',
          blue: '#6BC5F2',
          lime: '#C5E063',
          orange: '#FF9F43',
          cream: '#FFF8E7',
        },
        paper: '#FFF8E7',
      },
      boxShadow: {
        'memphis': '4px 4px 0px 0px #0a0a0a',
        'memphis-lg': '6px 6px 0px 0px #0a0a0a',
        'memphis-sm': '2px 2px 0px 0px #0a0a0a',
        'memphis-inset': 'inset 3px 3px 0px 0px #0a0a0a',
      },
      keyframes: {
        'pop-in': {
          '0%': { transform: 'scale(0.6) rotate(-5deg)', opacity: '0' },
          '60%': { transform: 'scale(1.05) rotate(2deg)', opacity: '1' },
          '100%': { transform: 'scale(1) rotate(0)', opacity: '1' },
        },
        'slide-up': {
          '0%': { transform: 'translateY(30px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        'slide-in-right': {
          '0%': { transform: 'translateX(-16px) rotate(-2deg)', opacity: '0' },
          '100%': { transform: 'translateX(0) rotate(0)', opacity: '1' },
        },
        'shake': {
          '0%, 100%': { transform: 'translateX(0) rotate(0)' },
          '20%': { transform: 'translateX(-8px) rotate(-3deg)' },
          '40%': { transform: 'translateX(8px) rotate(3deg)' },
          '60%': { transform: 'translateX(-5px) rotate(-2deg)' },
          '80%': { transform: 'translateX(5px) rotate(2deg)' },
        },
        'bounce-soft': {
          '0%, 100%': { transform: 'translateY(0) rotate(-2deg)' },
          '50%': { transform: 'translateY(-8px) rotate(2deg)' },
        },
        'wiggle': {
          '0%, 100%': { transform: 'rotate(0deg)' },
          '25%': { transform: 'rotate(-5deg)' },
          '75%': { transform: 'rotate(5deg)' },
        },
        'confetti-fall': {
          '0%': { transform: 'translateY(-10vh) rotate(0deg)', opacity: '1' },
          '100%': { transform: 'translateY(110vh) rotate(720deg)', opacity: '0' },
        },
        'pulse-ring': {
          '0%': { transform: 'scale(0.9)', opacity: '0.6' },
          '70%': { transform: 'scale(1.4)', opacity: '0' },
          '100%': { transform: 'scale(1.4)', opacity: '0' },
        },
        'spin-slow': {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0) rotate(0deg)' },
          '50%': { transform: 'translateY(-12px) rotate(5deg)' },
        },
        'float-delayed': {
          '0%, 100%': { transform: 'translateY(0) rotate(0deg)' },
          '50%': { transform: 'translateY(-8px) rotate(-5deg)' },
        },
      },
      animation: {
        'pop-in': 'pop-in 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) both',
        'slide-up': 'slide-up 0.5s ease-out both',
        'slide-in-right': 'slide-in-right 0.35s ease-out both',
        'shake': 'shake 0.5s ease-in-out',
        'bounce-soft': 'bounce-soft 1.5s ease-in-out infinite',
        'wiggle': 'wiggle 0.6s ease-in-out',
        'confetti-fall': 'confetti-fall linear forwards',
        'pulse-ring': 'pulse-ring 1.5s ease-out infinite',
        'spin-slow': 'spin-slow 12s linear infinite',
        'float': 'float 4s ease-in-out infinite',
        'float-delayed': 'float-delayed 5s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
